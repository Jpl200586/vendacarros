document.getElementById('dynamic-form').addEventListener('submit', function(event) {
    event.preventDefault();

    var formData = new FormData(event.target);

    fetch("YOUR_DEPLOYED_APPS_SCRIPT_URL", {
        method: "POST",
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        alert(data.result);
    })
    .catch(error => {
        console.error('Erro:', error);
    });
});

function addQuestion() {
    const container = document.getElementById('questions-container');
    const questionWrapper = document.createElement('div');
    questionWrapper.classList.add('question-wrapper');

    const questionLabel = document.createElement('label');
    questionLabel.textContent = 'Digite a pergunta:';
    questionWrapper.appendChild(questionLabel);

    const questionInput = document.createElement('input');
    questionInput.type = 'text';
    questionInput.name = 'pergunta';
    questionInput.required = true;
    questionWrapper.appendChild(questionInput);

    const typeLabel = document.createElement('label');
    typeLabel.textContent = 'Tipo de resposta:';
    questionWrapper.appendChild(typeLabel);

    const questionType = document.createElement('select');
    questionType.name = 'tipoResposta';
    const options = ['Texto', 'Múltipla Escolha', 'Caixas de Seleção'];
    options.forEach(option => {
        const opt = document.createElement('option');
        opt.value = option.toLowerCase();
        opt.textContent = option;
        questionType.appendChild(opt);
    });
    questionWrapper.appendChild(questionType);

    container.appendChild(questionWrapper);
}
