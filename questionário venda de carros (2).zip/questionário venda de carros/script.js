// Função para preencher os dados do endereço ao digitar o CEP
document.getElementById('cep').addEventListener('blur', function(event) {
    var cep = event.target.value.replace(/\D/g, '');

    if (cep.length != 8) {
        alert('CEP inválido');
        return;
    }

    var url = 'https://viacep.com.br/ws/' + cep + '/json/';

    fetch(url)
        .then(response => response.json())
        .then(data => {
            if (!('erro' in data)) {
                document.getElementById('rua').value = data.logradouro;
                document.getElementById('bairro').value = data.bairro;
                document.getElementById('cidade').value = data.localidade;
                document.getElementById('uf').value = data.uf;
            } else {
                alert('CEP não encontrado');
            }
        })
        .catch(error => {
            console.error('Erro ao buscar dados do CEP:', error);
        });
});

// Função para enviar o formulário e salvar os dados no Google Sheets
document.getElementById('dynamic-form').addEventListener('submit', function(event) {
    event.preventDefault();

    var formData = new FormData(event.target);
    var urlParams = new URLSearchParams(formData);

    fetch("https://script.google.com/macros/s/AKfycbyKecKMh0-mnn--U9vcfRjb37VZ7gVQ7pZgCSl9iTKfhLvOgjGiW1g10niua4wxsRJing/exec" + urlParams.toString(), {
        method: "POST",
        mode: "no-cors"
    })
    .then(response => {
        if (response.ok) {
            return response.json();
        } else {
            throw new Error("Erro ao enviar dados");
        }
    })
    .then(data => {
        alert(data.result);
    })
    .catch(error => {
        console.error('Erro:', error);
    });
});


// Função para adicionar perguntas dinâmicas
function addQuestion() {
    const container = document.getElementById('questions-container');
    const questionWrapper = document.createElement('div');
    questionWrapper.classList.add('question-wrapper');

    const questionLabel = document.createElement('label');
    questionLabel.textContent = 'Digite a pergunta:';
    questionWrapper.appendChild(questionLabel);

    const questionInput = document.createElement('input');
    questionInput.type = 'text';
    questionInput.name = 'pergunta';
    questionInput.required = true;
    questionWrapper.appendChild(questionInput);

    const typeLabel = document.createElement('label');
    typeLabel.textContent = 'Tipo de resposta:';
    questionWrapper.appendChild(typeLabel);

    const questionType = document.createElement('select');
    questionType.name = 'tipoResposta';
    const options = ['Texto', 'Múltipla Escolha', 'Caixas de Seleção'];
    options.forEach(option => {
        const opt = document.createElement('option');
        opt.value = option.toLowerCase();
        opt.textContent = option;
        questionType.appendChild(opt);
    });
    questionWrapper.appendChild(questionType);

    container.appendChild(questionWrapper);
}
const socket = new WebSocket('wss://127.0.0.1:5500/fsws');

socket.addEventListener('open', function (event) {
    console.log('Conexão aberta!');
});

socket.addEventListener('error', function (error) {
    console.error('Erro:', error);
});
