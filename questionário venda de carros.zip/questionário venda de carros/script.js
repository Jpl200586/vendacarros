document.getElementById('dynamic-form').addEventListener('submit', function(event) {
    event.preventDefault();

    var formData = new FormData(event.target);
    var data = {};
    formData.forEach((value, key) => {
        data[key] = value;
    });

    fetch("https://script.google.com/macros/s/AKfycbw3vB0MHlXagJbKLCMGpHDrtCFhP8DBYvKpNlGeU0Es1tHIRMhXaKEmUo7w6pjhrtcYPw/exec", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(data)
    })
    .then(response => response.json())
    .then(data => {
        alert(data.result);
    })
    .catch(error => {
        console.error('Erro:', error);
    });
});
